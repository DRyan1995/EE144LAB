This is the EE144 LAB1 code folder by Yecheng Xiang

square_openloop_nonblocking.m is the openloop control to make the robot move a squre.
square_closeloop_nonblocking.m is the closeloop(pid control) control.

To make the pid control as a p control, please change the parameter in pidcontrol.m -- make Ki and Kd ZERO!

My optimal value for PID control is Kp = 0.8, Kd = 0.5, Ki = 0.01

Thanks
